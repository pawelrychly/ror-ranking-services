rorranking
==========

An implementation of Robust Ordinal Regression Ranking methods


Credits
==========
Some parts of the *rorutadis* code are based on [ror package](http://cran.r-project.org/web/packages/ror/index.html "ror package") by Tommi Tervonen. A code of xmcda helper functions are based on rxmcda package by Patrick Meyer and Sebastien Bigaret